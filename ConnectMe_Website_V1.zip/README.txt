CONNECTME WEBSITE - FIRST VERSION

This is a front-end prototype for ConnectMe.
Features:
- Home feed
- Create posts
- Like buttons
- Messages and chat composer
- Notifications
- Profile
- Settings
- Responsive mobile layout

HOW TO TEST:
1. Unzip the folder.
2. Open index.html in Chrome.
3. It works without a server for this prototype.

IMPORTANT:
This version does not yet have real user accounts, cloud database, real-time messaging, image uploads, or authentication. Those require a backend.
