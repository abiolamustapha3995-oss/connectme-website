const app=document.getElementById('app');
const posts=[
 {name:'Maya',text:'Welcome to ConnectMe! 🎉 What are you sharing today?',likes:12,letter:'M'},
 {name:'Jordan',text:'Beautiful day to connect with friends and family. ❤️',likes:8,letter:'J'}
];
const chats=[['Maya','Hey! Welcome to ConnectMe 👋','M'],['Jordan','Are you online?','J'],['Taylor','Nice post!','T']];

function page(name){
 document.querySelectorAll('[data-page]').forEach(x=>x.classList.toggle('active',x.dataset.page===name));
 if(name==='home') home(); else if(name==='messages') messages(); else if(name==='profile') profile(); else if(name==='notifications') notifications(); else settings();
}
function home(){
 app.innerHTML=`<div class="card postbox"><h2>Home</h2><textarea id="newPost" rows="3" placeholder="What's on your mind?"></textarea><div style="margin-top:10px;text-align:right"><button class="primary" onclick="addPost()">Create post</button></div></div>
 <div id="feed">${posts.map((p,i)=>post(p,i)).join('')}</div>`;
}
function post(p,i){return `<article class="card post"><div class="posthead"><span class="avatar">${p.letter}</span><div><b>${p.name}</b><div class="muted">Just now · 🌎</div></div></div><p>${escapeHtml(p.text)}</p><div class="actions"><button onclick="like(${i})">❤️ ${p.likes}</button><button>💬 Comment</button><button>↗ Share</button></div></article>`}
function like(i){posts[i].likes++;home()}
function addPost(){const t=document.getElementById('newPost').value.trim();if(!t)return;posts.unshift({name:'You',text:t,likes:0,letter:'Y'});home()}
function messages(){
 app.innerHTML=`<div class="card"><h2>Messages 💬</h2><div class="chat-list">${chats.map((c,i)=>`<div class="chat" onclick="openChat(${i})"><span class="avatar">${c[2]}</span><div class="chat-info"><b>${c[0]}</b><div class="muted">${c[1]}</div></div><span>›</span></div>`).join('')}</div></div>`;
}
function openChat(i){
 const name=chats[i][0];
 app.innerHTML=`<div class="card chatbox"><h2>💬 ${name}</h2><div class="messages" id="msgs"><div class="bubble">${escapeHtml(chats[i][1])}</div><div class="bubble me">Hi ${name}! 👋</div></div><div class="composer"><input id="msg" placeholder="Write a message..." onkeydown="if(event.key==='Enter')sendMsg()"><button class="send" onclick="sendMsg()">Send</button></div></div>`;
}
function sendMsg(){const x=document.getElementById('msg');if(!x.value.trim())return;const m=document.getElementById('msgs');m.insertAdjacentHTML('beforeend',`<div class="bubble me">${escapeHtml(x.value)}</div>`);x.value='';m.scrollTop=m.scrollHeight}
function profile(){app.innerHTML=`<div class="card"><div class="profile-cover"></div><div class="profile-main"><span class="avatar">Y</span><h2>You</h2><p class="muted">@connectme_user · Share • Connect • Belong.</p><button class="primary">Edit profile</button></div></div>`}
function notifications(){app.innerHTML=`<div class="card"><h2>Notifications 🔔</h2><div class="chat"><span>❤️</span><div><b>Maya liked your post</b><div class="muted">2 minutes ago</div></div></div><div class="chat"><span>💬</span><div><b>Jordan sent you a message</b><div class="muted">10 minutes ago</div></div></div></div>`}
function settings(){app.innerHTML=`<div class="card"><h2>Settings ⚙️</h2><p>Account</p><button class="nav">🔒 Privacy</button><button class="nav">🔔 Notifications</button><button class="nav">🌙 Appearance</button><button class="nav">❓ Help & support</button></div>`}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>page(b.dataset.page)));
document.getElementById('searchInput').addEventListener('input',e=>{if(e.target.value.trim()) messages();});
home();
